#!/usr/bin/python
# coding=utf-8
from __future__ import print_function
import sys
import hashlib
import os
import json
import time
sys.path.append('../../androguard')
from androguard.core.bytecode import *
from androguard.core.bytecodes.apk import *
from androguard.core.analysis.analysis import *
#import androlyze as anz
from math import log
#path_dir = '/home/alisa/dajbog/apks/bad_apps_train'
path_dir = '../dendroid_data/bad_train'
save_file_ccs = 'CCs.txt'
save_file_vecs = 'fam_vecs.txt'
save_file_iff = 'iff.txt'
time1 = time.time()
f = open('sha256_family.csv')
dic = []
fam_lst = []
app_lst = []
for line in f:
        l = line.split()[0].split(',')
        dic.append((l[0], l[1]))
        if not l[1] in fam_lst:
                fam_lst.append(l[1])
        app_lst.append(l[0]) 
fams_number = len(fam_lst)
app_fam = dict(dic) #dictionary to find family of app
fam_lst1 = map(lambda x: (x, []), fam_lst)
fam_lst2 = map(lambda x: (x, []), fam_lst)
fam_lst3 = map(lambda x: (x, []), fam_lst)
fam_cc = dict(fam_lst1) #dictionary to collect code chunks of families
fam_app = dict(fam_lst2)#dictionary to find all apps assosiated with families
vect_fam  = dict(fam_lst3) #family vectors from article
for app in app_fam:
        fam_app[app_fam[app]].append(app) #collect apps associated with each family
app_lst = map(lambda x: (x, []), app_lst)
app_cc = dict(app_lst) #dictionary to collect code chunks associated with apps
freq = {}
list_p = os.listdir(path_dir)
nm = len(list_p)
i = 0
for apk_name in list_p:
        try:
                apk_path = path_dir + '/' + apk_name
                family = app_fam[apk_name]
                a = APK(apk_path)
                d = dvm.DalvikVMFormat( a.get_dex() )
                dx = uVMAnalysis(d)
                methods = d.get_methods()
                for method in methods:
                        s = dx.get_method_signature(method, predef_sign = SIGNATURE_L0_0) 
                        sign = s.get_string() #get code chunk
                        if len(sign) == 0:
                                continue
                        if not sign in app_cc[apk_name]: #if no such CC - append
                                app_cc[apk_name].append(sign)
                                freq[sign, apk_name] = 1 #frequency is 1
                        else:
                                freq[sign, apk_name] +=1 #if already exists - increase frequency of CC in app
                        if not sign in fam_cc[family]:
                                fam_cc[family].append(sign) 
		i+=1
		print(i, '/', nm)
        except Exception as error:
                print(error)
                continue

all_cc = []
for item in fam_cc:
        for cc in fam_cc[item]:
                if not cc in all_cc:
                        all_cc.append(cc) #collect all CC list
k = len(all_cc)
iff = {}
print('finished')
print(k)
#count iff:
for cc in all_cc:
        count = 1
        for item in fam_cc:
                if cc in fam_cc[item]:
                        count += 1
        iff[cc] = log(fams_number*1.0/count)
#count ccf:
for family in fam_app:
        for cc in all_cc:
                sum_freq = 0
                max_freq = 0
                for app in fam_app[family]:
                        try:
                                cur_freq = freq[cc, app]
                        except:
                                cur_freq = 0
                        sum_freq += cur_freq
                        if cur_freq > max_freq:
                                max_freq = cur_freq
                if sum_freq == 0:
                        ccf = 0
                else:
                        ccf = sum_freq * 1.0/ max_freq
                vect_fam[family].append(ccf * iff[cc])
#print(vect_fam)
f = open(save_file_ccs, 'w')
f.write(json.dumps(all_cc))
f.close()
f = open(save_file_vecs, 'w')
f.write(json.dumps(vect_fam))
f.close()
f = open(save_file_iff, 'w')
f.write(json.dumps(iff))
f.close()
time2 = time.time() - time1
print(time2)
f = open('time.txt', 'w')
f.write(time2)
f.close()
