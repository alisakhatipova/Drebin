#!/usr/bin/python

import numpy as np
import matplotlib.pyplot as plt
import mlpy
import os
import json
import time
import numpy as np
from scipy import spatial
import sys
import hashlib
sys.path.append('../../androguard')
from androguard.core.bytecode import *
from androguard.core.bytecodes.apk import *
from androguard.core.analysis.analysis import *
#import androlyze as anz
path_dir = '../dendroid_data/bad_thres'
save_file_ccs = 'CCs.txt'
save_file_vecs = 'fam_vecs.txt'
save_file_iff = 'iff.txt'
f = open(save_file_ccs, 'r')
all_ccs = json.loads(f.read())
f.close()
f = open(save_file_vecs, 'r')
fam_vecs = json.loads(f.read())
f.close()
f = open(save_file_iff, 'r')
iff = json.loads(f.read())
f.close()
time1 = time.time()
list_p = os.listdir(path_dir)
f = open('distances.txt', 'w')
k = len(list_p)
i = 0
for apk_name in list_p:
	apk_path = path_dir + '/' + apk_name
	app_cc = []
	freq = {}
	try:
	    a = APK(apk_path)
	    d = dvm.DalvikVMFormat( a.get_dex() )
	    dx = uVMAnalysis(d)
	    methods = d.get_methods()
	    for method in methods:
		s = dx.get_method_signature(method, predef_sign = SIGNATURE_L0_0)
		sign = s.get_string()
		if len(sign) == 0:
		    continue
		if not sign in app_cc:
		    app_cc.append(sign)
		    freq[sign] = 1
		else:
		    freq[sign] +=1
	except Exception as error:
	    print(error)
	u = []

	for cc in all_ccs:
	    if cc in app_cc:
		u.append(freq[cc] * iff[cc])
	    else:
		u.append(0.0)
	dist = 1
	for vec in fam_vecs:
	    cur_dist =  spatial.distance.cosine(fam_vecs[vec], u)
	    if cur_dist < dist:
		dist = cur_dist
	i += 1
	print(dist)
	print(i, '/', k)
	f.write(str(dist))
time2 = time.time() - time1
f = open('time.txt', 'w')
f.write(str(time2))
